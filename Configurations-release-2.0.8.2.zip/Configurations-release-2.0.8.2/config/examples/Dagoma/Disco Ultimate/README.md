# Dagoma Disco Ultimate Configuration

## Requirements
- Dagoma Disco Ultimate with F5 board
- Reprap screen

## TODO
The pause button feature is not yet implemented but its behavior can be replicated with the screen.